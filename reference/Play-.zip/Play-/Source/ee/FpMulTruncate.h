#ifndef _FPMULTRUNCATE_H_
#define _FPMULTRUNCATE_H_

#include "Types.h"

uint32 FpMulTruncate(uint32, uint32);

#endif
