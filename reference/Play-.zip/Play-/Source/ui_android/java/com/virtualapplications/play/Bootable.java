package com.virtualapplications.play;

//This needs to mirror the layout of the Bootable structure in BootablesDbClient.h
public class Bootable
{
	String path;
	String discId;
	public String title;
	String coverUrl;
	int lastBootedTime;
	public String overview;
}
