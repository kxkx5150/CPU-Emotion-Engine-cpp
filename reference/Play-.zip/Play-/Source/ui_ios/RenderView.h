#import <UIKit/UIKit.h>

@interface RenderView : UIView
{
@private
	BOOL hasRetinaDisplay;
}

@end
