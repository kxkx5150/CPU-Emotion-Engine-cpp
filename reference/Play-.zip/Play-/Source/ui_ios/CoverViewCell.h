#import <UIKit/UIKit.h>

@interface CoverViewCell : UICollectionViewCell

@property(nonatomic, retain) IBOutlet UILabel* nameLabel;

@end
