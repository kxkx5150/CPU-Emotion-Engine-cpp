#pragma once

void StartSimulateDebugger();
void StopSimulateDebugger();
