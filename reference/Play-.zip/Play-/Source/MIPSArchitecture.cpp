#include "MIPSArchitecture.h"

CMIPSArchitecture::CMIPSArchitecture(MIPS_REGSIZE regSize)
    : CMIPSInstructionFactory(regSize)
{
}
