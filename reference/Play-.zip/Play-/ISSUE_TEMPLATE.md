## Quick summary
Please briefly describe what is not working correctly

## System Details
Describe the ambient being used to run Play!
Information needed:
- Operating system (including the version)
- Hardware (GPU and CPU, for android you can search for your device model here https://www.gsmarena.com/ for specifications)
- Version of Play!

## Issue Details
Describe in details the problem you had and the expected behavior

## Screenshots/Videos
Drag and drop (or link to) videos or images that could help us understand the problem.
